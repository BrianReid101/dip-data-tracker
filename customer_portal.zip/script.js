document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("dipForm");
    const status = document.getElementById("status");
    const dateInput = document.getElementById("date");
    dateInput.valueAsDate = new Date();

    form.addEventListener("submit", (e) => {
        e.preventDefault();
        status.innerText = "✅ DIP entry submitted (simulated)";
        form.reset();
        dateInput.valueAsDate = new Date();
    });
});
