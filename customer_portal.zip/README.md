# DIP Submission Portal

A simple customer-friendly web interface to submit DIP data.

## Features
- Easy form input for Site, DIP Volume/%, Contact Details
- Auto-sets today's date
- Mobile-friendly and clean design
- No backend required for demo; Power Automate integration optional

## How to Use
1. Upload all files to a GitHub repository.
2. Enable GitHub Pages in repository settings (use `main` branch, root directory).
3. Share the GitHub Pages link with customers.

## Hosting Help
- Go to your repo > Settings > Pages
- Set source to `main` branch and root
- Click Save and copy the URL GitHub gives you

## Integration Notes
To log data:
- Connect a form submission service (like Netlify Forms)
- Or build a Power Automate flow to catch webhook requests

*Contact your dev for linking with Excel or Power BI*

